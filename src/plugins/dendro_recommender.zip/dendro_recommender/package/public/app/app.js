'use strict';

// Declare app level module which depends on filters, and services
angular.module('dendroRecommenderApp', [
        'dendroRecommenderApp.controller',
        'dendroRecommenderApp.services',
        'dendroRecommenderApp.directives',
        'ngAnimate'
    ]);
